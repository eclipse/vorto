package device.trackingdevice.model;

public class TrackingDevice {
	private Location location;
	
	private String resourceId;
	
	public TrackingDevice(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}
	
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public String getResourceId() {
		return resourceId;
	}
}
