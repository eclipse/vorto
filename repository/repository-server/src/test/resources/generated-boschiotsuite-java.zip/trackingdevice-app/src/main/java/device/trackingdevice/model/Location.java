package device.trackingdevice.model;

import java.util.HashMap;
import java.util.Map;

public class Location {
    
    /** Status properties */
    
    /**
    * Tracks the x axis
    */
    @com.google.gson.annotations.SerializedName("x")
    private float x;
    /**
    * Tracks the y axis
    */
    @com.google.gson.annotations.SerializedName("y")
    private float y;
    /**
    * Tracks the z axis
    */
    @com.google.gson.annotations.SerializedName("z")
    private float z;
    
    /** Configuration properties */
    
    	
    /**
    * Setter for x.
    */
    public void setX(float x) {
    	this.x = x;
    }
    /**
    * Getter for x.
    */
    public float getX() {
    	return this.x;
    }
    /**
    * Setter for y.
    */
    public void setY(float y) {
    	this.y = y;
    }
    /**
    * Getter for y.
    */
    public float getY() {
    	return this.y;
    }
    /**
    * Setter for z.
    */
    public void setZ(float z) {
    	this.z = z;
    }
    /**
    * Getter for z.
    */
    public float getZ() {
    	return this.z;
    }
    
    public Map getStatusProperties() {
        Map<String, Object> status = new HashMap<String, Object>();
        status.put("x", this.x);
        status.put("y", this.y);
        status.put("z", this.z);
    	return status;
    }
    public Map getConfigurationProperties() {
        Map<String, Object> configuration = new HashMap<String, Object>();
        return configuration;
    }
}
