package device.trackingdevice;

import org.apache.log4j.Logger;

import device.trackingdevice.model.Location;
import device.trackingdevice.service.hono.HonoDataService;

/**
 * Example App that uses the Hono Data Service by sending random data to Eclipse Hono MQTT Connector
 */
public class TrackingDeviceApp {

	private static final Logger LOGGER = Logger.getLogger(TrackingDeviceApp.class);

	/**************************************************************************/
	/* Configuration Section */
	/* Adjust according to your Endpoint Configuration*/
	/**************************************************************************/

	// Hono MQTT Endpoint
	private static final String MQTT_ENDPOINT = "<INSERT HONO MQTT ENDPOINT HERE>";

	// Your Tenant
	private static final String HONO_TENANT = "DEFAULT_TENANT";

	// Your DeviceId
	private static final String DEVICE_ID = "<INSERT DEVICE ID HERE>";
	
	// Device authentication ID
	private static final String AUTH_ID = "<INSERT DEVICE AUTH ID HERE>";
	
	// Ditto topic , e.g. com.mycompany/4711
	private static final String DITTO_TOPIC = "com.mycompany/1234";

	// Device authentication Password
	private static final String PASSWORD = "ENTER_DEVICE_PASSWORD";
	
	private static final long SEND_INTERVAL_IN_SECONDS = 2;

	public static void main(final String... args) {
		HonoDataService honoDataService = new HonoDataService(MQTT_ENDPOINT, HONO_TENANT, DITTO_TOPIC, 
				DEVICE_ID, AUTH_ID,PASSWORD);
		
		while (true) {
			honoDataService.publishLocation(DEVICE_ID,readLocation());
			try {
				Thread.sleep(SEND_INTERVAL_IN_SECONDS * 1000);
			} catch (InterruptedException e) {
				LOGGER.error(e);
			}
		}
	}

	/**
	* Reads the location from the device
	*/
	private static Location readLocation() {
		Location location = new Location();
		//Status properties
		location.setX(Math.round(new java.util.Random().nextFloat()*(float)100));
		location.setY(Math.round(new java.util.Random().nextFloat()*(float)100));
		location.setZ(Math.round(new java.util.Random().nextFloat()*(float)100));
		//Configuration properties
		return location;
	}

}
