import netifaces
import paho.mqtt.client as mqtt
import datetime, threading, time
import model.functionblock.Lamp as lamp 
import model.functionblock.Lamp as spareLamp 
import model.functionblock.Address as location 
import model.infomodel.StreetLamp as StreetLamp
import model.DittoSerializer as DittoSerializer

# DEVICE CONFIG GOES HERE
hono_tenant = "<hono_tenant>"
hono_password = "<ADD PASSWORD HERE>"
hono_endpoint = "<hono_endpoint>"
hono_deviceId = "<hono_deviceId>"
hono_clientId = hono_deviceId
hono_authId = hono_deviceId + "@" + hono_tenant
hono_certificatePath = "<ADD PATH TO CERTIFICATE HERE>"
ditto_topic = "com.mycompany/4711"


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    global next_call

    if rc != 0:
        print("Connection to MQTT broker failed: " + str(rc))
        return

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.

    # BEGIN SAMPLE CODE
    client.subscribe("commands/" + hono_tenant + "/")
    # END SAMPLE CODE

    # Time stamp when the periodAction function shall be called again
    next_call = time.time()
    
    # Start the periodic task for publishing MQTT messages
    periodicAction()

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    
    ### BEGIN SAMPLE CODE
    
    print(msg.topic+" "+str(msg.payload))

    ### END SAMPLE CODE

# The functions to publish the functionblocks data
def publishLamp():
    payload = ser.serialize_functionblock("lamp", infomodel.lamp, ditto_topic, hono_deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
    
def publishSpareLamp():
    payload = ser.serialize_functionblock("spareLamp", infomodel.spareLamp, ditto_topic, hono_deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
    
def publishLocation():
    payload = ser.serialize_functionblock("location", infomodel.location, ditto_topic, hono_deviceId)
    print("Publish Payload: ", payload, " to Topic: ", publishTopic)
    client.publish(publishTopic, payload)
    
# The function that will be executed periodically once the connection to the MQTT broker was established
def periodicAction():
    global next_call

    ### BEGIN SAMPLE CODE

    # Setting properties of function blocks
    infomodel.lamp.blinking += 1
    infomodel.lamp.onOff += 1
    infomodel.lamp.dimmer += 1
    infomodel.lamp.lamp_type = ""
    infomodel.lamp.biggerThanInt += 1
    infomodel.spareLamp.blinking += 1
    infomodel.spareLamp.onOff += 1
    infomodel.spareLamp.dimmer += 1
    infomodel.spareLamp.lamp_type = ""
    infomodel.spareLamp.biggerThanInt += 1
    infomodel.location.deviceName = ""

    ### END SAMPLE CODE

    # Publish payload
    publishLamp()
    publishSpareLamp()
    publishLocation()

    # Schedule next call
    next_call = next_call + timePeriod;
    threading.Timer(next_call - time.time(), periodicAction).start()


# Initialization of Information Model 
infomodel = StreetLamp.StreetLamp()
infomodel.lamp.blinking = 0
infomodel.lamp.onOff = 0
infomodel.lamp.dimmer = 0
infomodel.lamp.lamp_type = ""
infomodel.lamp.biggerThanInt = 0
infomodel.spareLamp.blinking = 0
infomodel.spareLamp.onOff = 0
infomodel.spareLamp.dimmer = 0
infomodel.spareLamp.lamp_type = ""
infomodel.spareLamp.biggerThanInt = 0
infomodel.location.deviceName = ""
infomodel.location.text = ""
infomodel.location.id = 0
infomodel.location.identifier = ""

# Create a serializer for the MQTT payload from the Information Model
ser = DittoSerializer.DittoSerializer()

# Timer variable for periodic function
next_call = 0

# Period for publishing data to the MQTT broker in seconds
timePeriod = 10

# Configuration of client ID and publish topic	
publishTopic = "telemetry/" + hono_tenant + "/" + hono_clientId

# Output relevant information for consumers of our information
print("Connecting client:    ", hono_clientId)
print("Publishing to topic:  ", publishTopic)

# Create the MQTT client
client = mqtt.Client(hono_clientId)
client.on_connect = on_connect
client.on_message = on_message

client.tls_set(hono_certificatePath)

client.username_pw_set(hono_authId, hono_password)

# Connect to the MQTT broker
client.connect(hono_endpoint, 8883, 60)

# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.loop_start()

while (1):
    pass
