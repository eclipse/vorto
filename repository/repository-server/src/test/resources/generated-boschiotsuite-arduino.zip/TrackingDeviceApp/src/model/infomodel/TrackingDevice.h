// TrackingDevice

#ifndef __INFOMODEL_TRACKINGDEVICE_H__
#define __INFOMODEL_TRACKINGDEVICE_H__

#include <WString.h>

#include "../functionblock/Location.h"

namespace com_test {
    class TrackingDevice
    {
       public:
            TrackingDevice();

            com_test::Location location;

            String serialize();
        private:
    };
}

#endif // __INFOMODEL_TRACKINGDEVICE_H__
