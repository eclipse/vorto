// TrackingDevice

#include "TrackingDevice.h"

using namespace com_test;

TrackingDevice::TrackingDevice() {}

String TrackingDevice::serialize() {}
