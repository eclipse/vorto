// Location

#ifndef __MODEL_LOCATION_H__
#define __MODEL_LOCATION_H__

#include <WString.h>


namespace com_test {
    class Location
    {
        public:
            Location();
            
            void setx(float value);
            float getx();
            void sety(float value);
            float gety();
            void setz(float value);
            float getz();

            String serialize(String ditto_namespace, String hono_deviceId, String fbName);
        private:
            float x;
            float y;
            float z;
    };
}

#endif // __MODEL_LOCATION_H__
