// Location

#include "Location.h"

using namespace com_test;

Location::Location(){}

void Location::setx(float value) {
	x = value;			
}

float Location::getx() {
	return x;
}
void Location::sety(float value) {
	y = value;			
}

float Location::gety() {
	return y;
}
void Location::setz(float value) {
	z = value;			
}

float Location::getz() {
	return z;
}


String Location::serialize(String ditto_topic, String hono_deviceId, String fbName) {
    String result = "{\"topic\":\""+ ditto_topic +"/things/twin/commands/modify\",";
    result += "\"headers\":{\"response-required\": false},";
    result += "\"path\":\"/features/" + fbName + "\",\"value\": { \"properties\": {";
    //Status Properties
    result += "\"status\": {";
    result += "\"x\" : " + String(x) + ",";
    result += "\"y\" : " + String(y) + ",";
    result += "\"z\" : " + String(z) + "";
    result += "}";

    result +=",";

    //Configuration Properties
    result += "\"configuration\": {";
    result += "}";
    result += "} } }";

    return result;
}
