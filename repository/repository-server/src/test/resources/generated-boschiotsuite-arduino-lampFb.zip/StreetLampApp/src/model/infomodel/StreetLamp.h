// StreetLamp

#ifndef __INFOMODEL_STREETLAMP_H__
#define __INFOMODEL_STREETLAMP_H__

#include <WString.h>

#include "../functionblock/Lamp.h"
#include "../functionblock/Lamp.h"
#include "../functionblock/Address.h"

namespace com_test {
    class StreetLamp
    {
       public:
            StreetLamp();

            com_test::Lamp lamp;
            com_test::Lamp spareLamp;
            com_test::Address location;

            String serialize();
        private:
    };
}

#endif // __INFOMODEL_STREETLAMP_H__
