// StreetLamp

#include "StreetLamp.h"

using namespace com_test;

StreetLamp::StreetLamp() {}

String StreetLamp::serialize() {}
