// Address

#include "Address.h"

using namespace com_test;

Address::Address(){}

void Address::setdeviceName(String value) {
	deviceName = value;			
}

String Address::getdeviceName() {
	return deviceName;
}

void Address::settext(String value) {
	text = value;			
}

String Address::gettext() {
	return text;
}
void Address::setzone(com_test::Zone value) {
	zone = value;			
}

com_test::Zone Address::getzone() {
	return zone;
}
void Address::setid(uint32_t value) {
	id = value;			
}

uint32_t Address::getid() {
	return id;
}
void Address::setidentifier(String value) {
	identifier = value;			
}

String Address::getidentifier() {
	return identifier;
}

String Address::serialize(String ditto_topic, String hono_deviceId, String fbName) {
    String result = "{\"topic\":\""+ ditto_topic +"/things/twin/commands/modify\",";
    result += "\"headers\":{\"response-required\": false},";
    result += "\"path\":\"/features/" + fbName + "\",\"value\": { \"properties\": {";
    //Status Properties
    result += "\"status\": {";
    result += "\"deviceName\" : \"" + String(deviceName) + "\" ";
    result += "}";

    result +=",";

    //Configuration Properties
    result += "\"configuration\": {";
    result += "\"text\" : \"" + String(text) + "\", ";
    result += "\"zone\" : \"" + String(zone) + "\", ";
    result += "\"id\" : " + String(id) + ",";
    result += "\"identifier\" : \"" + String(identifier) + "\" ";
    result += "}";
    result += "} } }";

    return result;
}
