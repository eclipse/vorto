// Lamp

#include "Lamp.h"

using namespace com_test;

Lamp::Lamp(){}

void Lamp::setblinking(bool value) {
	blinking = value;			
}

bool Lamp::getblinking() {
	return blinking;
}
void Lamp::setonOff(uint32_t value) {
	onOff = value;			
}

uint32_t Lamp::getonOff() {
	return onOff;
}
void Lamp::setdimmer(float value) {
	dimmer = value;			
}

float Lamp::getdimmer() {
	return dimmer;
}
void Lamp::setlamp_type(String value) {
	lamp_type = value;			
}

String Lamp::getlamp_type() {
	return lamp_type;
}
void Lamp::setbiggerThanInt(uint64_t value) {
	biggerThanInt = value;			
}

uint64_t Lamp::getbiggerThanInt() {
	return biggerThanInt;
}

void Lamp::setdefaultColour(com_test::Colour value) {
	defaultColour = value;			
}

com_test::Colour Lamp::getdefaultColour() {
	return defaultColour;
}

String Lamp::serialize(String ditto_topic, String hono_deviceId, String fbName) {
    String result = "{\"topic\":\""+ ditto_topic +"/things/twin/commands/modify\",";
    result += "\"headers\":{\"response-required\": false},";
    result += "\"path\":\"/features/" + fbName + "\",\"value\": { \"properties\": {";
    //Status Properties
    result += "\"status\": {";
    result += "\"blinking\" : " + String(blinking == 1 ? "true" : "false") + ",";
    result += "\"onOff\" : " + String(onOff) + ",";
    result += "\"dimmer\" : " + String(dimmer) + ",";
    result += "\"lamp_type\" : \"" + String(lamp_type) + "\", ";
    result += "\"biggerThanInt\" : " + String(biggerThanInt) + "";
    result += "}";

    result +=",";

    //Configuration Properties
    result += "\"configuration\": {";
    result += defaultColour.serialize();
    result += "}";
    result += "} } }";

    return result;
}
