// Zone

#ifndef __ENUM_ZONE_H__
#define __ENUM_ZONE_H__

namespace com_test {
    enum Zone {
        NORTH,
        SOUTH,
        EAST,
        WEST,
        CENTER
        };
}
#endif // __ENUM_ZONE_H__
