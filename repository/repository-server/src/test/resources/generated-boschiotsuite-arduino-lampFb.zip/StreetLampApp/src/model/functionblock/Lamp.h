// Lamp

#ifndef __MODEL_LAMP_H__
#define __MODEL_LAMP_H__

#include <WString.h>

#include "../datatype/entity/Colour.h"

namespace com_test {
    class Lamp
    {
        public:
            Lamp();
            
            void setblinking(bool value);
            bool getblinking();
            void setonOff(uint32_t value);
            uint32_t getonOff();
            void setdimmer(float value);
            float getdimmer();
            void setlamp_type(String value);
            String getlamp_type();
            void setbiggerThanInt(uint64_t value);
            uint64_t getbiggerThanInt();
            void setdefaultColour(com_test::Colour value);
            com_test::Colour getdefaultColour();

            String serialize(String ditto_namespace, String hono_deviceId, String fbName);
        private:
            bool blinking;
            uint32_t onOff;
            float dimmer;
            String lamp_type;
            uint64_t biggerThanInt;
            com_test::Colour defaultColour;
    };
}

#endif // __MODEL_LAMP_H__
