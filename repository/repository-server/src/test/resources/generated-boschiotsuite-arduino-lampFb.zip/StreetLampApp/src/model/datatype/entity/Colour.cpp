// Colour

#include "Colour.h"

using namespace com_test;

Colour::Colour(){}

void Colour::setred(uint32_t value) {
    red = value;          
}

uint32_t Colour::getred() {
    return red;
}
void Colour::setgreen(uint32_t value) {
    green = value;          
}

uint32_t Colour::getgreen() {
    return green;
}
void Colour::setblue(uint32_t value) {
    blue = value;          
}

uint32_t Colour::getblue() {
    return blue;
}

String Colour::serialize() {
    String result = "\"Colour\": {";
        result += "\"red\": " + String(red) + ",";
        result += "\"green\": " + String(green) + ",";
        result += "\"blue\": " + String(blue) + ",";
        result += "}";

    return result;
}
