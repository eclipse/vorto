// Address

#ifndef __MODEL_ADDRESS_H__
#define __MODEL_ADDRESS_H__

#include <WString.h>

#include "../datatype/enum/Zone.h"

namespace com_test {
    class Address
    {
        public:
            Address();
            
            void setdeviceName(String value);
            String getdeviceName();
            void settext(String value);
            String gettext();
            void setzone(com_test::Zone value);
            com_test::Zone getzone();
            void setid(uint32_t value);
            uint32_t getid();
            void setidentifier(String value);
            String getidentifier();

            String serialize(String ditto_namespace, String hono_deviceId, String fbName);
        private:
            String deviceName;
            String text;
            com_test::Zone zone;
            uint32_t id;
            String identifier;
    };
}

#endif // __MODEL_ADDRESS_H__
