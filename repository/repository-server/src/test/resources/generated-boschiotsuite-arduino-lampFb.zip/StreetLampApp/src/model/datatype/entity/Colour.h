// Colour

#ifndef __ENTITY_COLOUR_H__
#define __ENTITY_COLOUR_H__

#include <WString.h>

namespace com_test {
    class Colour
    {
        public:
            Colour();
            
            void setred(uint32_t value);
            uint32_t getred();
            void setgreen(uint32_t value);
            uint32_t getgreen();
            void setblue(uint32_t value);
            uint32_t getblue();
            
            String serialize();
        private:
            uint32_t red;
            uint32_t green;
            uint32_t blue;
    };
}
#endif // __ENTITY_COLOUR_H__
