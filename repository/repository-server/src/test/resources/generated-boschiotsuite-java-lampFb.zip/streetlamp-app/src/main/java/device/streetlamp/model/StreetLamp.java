package device.streetlamp.model;

public class StreetLamp {
	private Lamp lamp;
	
	private String resourceId;
	
	public StreetLamp(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public Lamp getLamp() {
		return lamp;
	}

	public void setLamp(Lamp lamp) {
		this.lamp = lamp;
	}
	
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public String getResourceId() {
		return resourceId;
	}
}
