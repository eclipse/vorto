package device.streetlamp.model;

public class StreetLamp {
	private Lamp lamp;
	private Lamp spareLamp;
	private Address location;
	
	private String resourceId;
	
	public StreetLamp(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public Lamp getLamp() {
		return lamp;
	}

	public void setLamp(Lamp lamp) {
		this.lamp = lamp;
	}
	
	public Lamp getSpareLamp() {
		return spareLamp;
	}

	public void setSpareLamp(Lamp spareLamp) {
		this.spareLamp = spareLamp;
	}
	
	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}
	
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public String getResourceId() {
		return resourceId;
	}
}
