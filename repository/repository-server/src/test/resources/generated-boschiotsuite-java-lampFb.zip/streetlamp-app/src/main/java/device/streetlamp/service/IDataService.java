package device.streetlamp.service;

import device.streetlamp.model.Lamp;
import device.streetlamp.model.Address;

public interface IDataService {
	
	/**
	 * publishes lamp data to the IoT Cloud backend
	 * @param resourceId 
	 * @param data
	 */
	void publishLamp(String resourceId, Lamp data);
	
	/**
	 * publishes spareLamp data to the IoT Cloud backend
	 * @param resourceId 
	 * @param data
	 */
	void publishSpareLamp(String resourceId, Lamp data);
	
	/**
	 * publishes location data to the IoT Cloud backend
	 * @param resourceId 
	 * @param data
	 */
	void publishLocation(String resourceId, Address data);
	
}

