package device.streetlamp.service;

import device.streetlamp.model.Lamp;

public interface IDataService {
	
	/**
	 * publishes lamp data to the IoT Cloud backend
	 * @param resourceId 
	 * @param data
	 */
	void publishLamp(String resourceId, Lamp data);
	
}

