package device.streetlamp.model;

import java.util.HashMap;
import java.util.Map;

public class Address {
    
    /** Status properties */
    
    /**
    * Only allow 2 uppercase or lowercase characters and 1 digit for device name
    */
    @com.google.gson.annotations.SerializedName("deviceName")
    private String deviceName;
    
    /** Configuration properties */
    
    /**
    * A string of text.
    */
    @com.google.gson.annotations.SerializedName("text")
    private String text;
    /**
    * the zone value is optional
    */
    @com.google.gson.annotations.SerializedName("zone")
    private device.streetlamp.model.datatypes.Zone zone;
    /**
    * id of the address
    */
    @com.google.gson.annotations.SerializedName("id")
    private int id;
    /**
    * 
    */
    @com.google.gson.annotations.SerializedName("identifier")
    private String identifier;
    	
    /**
    * Setter for deviceName.
    */
    public void setDeviceName(String deviceName) {
    	this.deviceName = deviceName;
    }
    /**
    * Getter for deviceName.
    */
    public String getDeviceName() {
    	return this.deviceName;
    }
    /**
    * Setter for text.
    */
    public void setText(String text) {
    	this.text = text;
    }
    /**
    * Getter for text.
    */
    public String getText() {
    	return this.text;
    }
    /**
    * Setter for zone.
    */
    public void setZone(device.streetlamp.model.datatypes.Zone zone) {
    	this.zone = zone;
    }
    /**
    * Getter for zone.
    */
    public device.streetlamp.model.datatypes.Zone getZone() {
    	return this.zone;
    }
    /**
    * Setter for id.
    */
    public void setId(int id) {
    	this.id = id;
    }
    /**
    * Getter for id.
    */
    public int getId() {
    	return this.id;
    }
    /**
    * Setter for identifier.
    */
    public void setIdentifier(String identifier) {
    	this.identifier = identifier;
    }
    /**
    * Getter for identifier.
    */
    public String getIdentifier() {
    	return this.identifier;
    }
    
    public Map getStatusProperties() {
        Map<String, Object> status = new HashMap<String, Object>();
        status.put("deviceName", this.deviceName);
    	return status;
    }
    public Map getConfigurationProperties() {
        Map<String, Object> configuration = new HashMap<String, Object>();
        configuration.put("text", this.text);
        configuration.put("zone", this.zone);
        configuration.put("id", this.id);
        configuration.put("identifier", this.identifier);
        return configuration;
    }
}
