package device.streetlamp.model;

import java.util.HashMap;
import java.util.Map;

public class Lamp {
    
    /** Status properties */
    
    /**
    * if the lamp is currently blinking or not
    */
    @com.google.gson.annotations.SerializedName("blinking")
    private boolean blinking;
    
    /** Configuration properties */
    
    	
    /**
    * Setter for blinking.
    */
    public void setBlinking(boolean blinking) {
    	this.blinking = blinking;
    }
    /**
    * Getter for blinking.
    */
    public boolean getBlinking() {
    	return this.blinking;
    }
    
    public Map getStatusProperties() {
        Map<String, Object> status = new HashMap<String, Object>();
        status.put("blinking", this.blinking);
    	return status;
    }
    public Map getConfigurationProperties() {
        Map<String, Object> configuration = new HashMap<String, Object>();
        return configuration;
    }
}
