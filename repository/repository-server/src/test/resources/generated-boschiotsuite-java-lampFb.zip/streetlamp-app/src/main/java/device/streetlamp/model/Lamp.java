package device.streetlamp.model;

import java.util.HashMap;
import java.util.Map;

public class Lamp {
    
    /** Status properties */
    
    /**
    * if the lamp is currently blinking or not
    */
    @com.google.gson.annotations.SerializedName("blinking")
    private boolean blinking;
    /**
    * if the lamp is currently off a zero (0) is set, otherwise any positive value
    */
    @com.google.gson.annotations.SerializedName("onOff")
    private int onOff;
    /**
    * Proportional control, float value between 0.00 and 1.00 as a percentage.
    */
    @com.google.gson.annotations.SerializedName("dimmer")
    private float dimmer;
    /**
    * The lamp type as a string depending on the use case.
    */
    @com.google.gson.annotations.SerializedName("lamp_type")
    private String lamp_type;
    /**
    * Value for constraint is validated according to the property type, in this case, Long instead of Int
    */
    @com.google.gson.annotations.SerializedName("biggerThanInt")
    private long biggerThanInt;
    
    /** Configuration properties */
    
    /**
    * The default colour of the lamp
    */
    @com.google.gson.annotations.SerializedName("defaultColour")
    private device.streetlamp.model.datatypes.Colour defaultColour;
    	
    /**
    * Setter for blinking.
    */
    public void setBlinking(boolean blinking) {
    	this.blinking = blinking;
    }
    /**
    * Getter for blinking.
    */
    public boolean getBlinking() {
    	return this.blinking;
    }
    /**
    * Setter for onOff.
    */
    public void setOnOff(int onOff) {
    	this.onOff = onOff;
    }
    /**
    * Getter for onOff.
    */
    public int getOnOff() {
    	return this.onOff;
    }
    /**
    * Setter for dimmer.
    */
    public void setDimmer(float dimmer) {
    	this.dimmer = dimmer;
    }
    /**
    * Getter for dimmer.
    */
    public float getDimmer() {
    	return this.dimmer;
    }
    /**
    * Setter for lamp_type.
    */
    public void setLamp_type(String lamp_type) {
    	this.lamp_type = lamp_type;
    }
    /**
    * Getter for lamp_type.
    */
    public String getLamp_type() {
    	return this.lamp_type;
    }
    /**
    * Setter for biggerThanInt.
    */
    public void setBiggerThanInt(long biggerThanInt) {
    	this.biggerThanInt = biggerThanInt;
    }
    /**
    * Getter for biggerThanInt.
    */
    public long getBiggerThanInt() {
    	return this.biggerThanInt;
    }
    /**
    * Setter for defaultColour.
    */
    public void setDefaultColour(device.streetlamp.model.datatypes.Colour defaultColour) {
    	this.defaultColour = defaultColour;
    }
    /**
    * Getter for defaultColour.
    */
    public device.streetlamp.model.datatypes.Colour getDefaultColour() {
    	return this.defaultColour;
    }
    
    public Map getStatusProperties() {
        Map<String, Object> status = new HashMap<String, Object>();
        status.put("blinking", this.blinking);
        status.put("onOff", this.onOff);
        status.put("dimmer", this.dimmer);
        status.put("lamp_type", this.lamp_type);
        status.put("biggerThanInt", this.biggerThanInt);
    	return status;
    }
    public Map getConfigurationProperties() {
        Map<String, Object> configuration = new HashMap<String, Object>();
        configuration.put("defaultColour", this.defaultColour);
        return configuration;
    }
}
