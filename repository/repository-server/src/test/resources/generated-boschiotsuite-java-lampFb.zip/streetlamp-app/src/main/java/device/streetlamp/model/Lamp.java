package device.streetlamp.model;

import java.util.HashMap;
import java.util.Map;

public class Lamp {
    
    /** Status properties */
    
    /**
    * if the lamp is currently blinking or not
    */
    @com.google.gson.annotations.SerializedName("blinking")
    private boolean blinking;
    /**
    * if the lamp is currently off a zero (0) is set, otherwise any positive value
    */
    @com.google.gson.annotations.SerializedName("onOff")
    private int onOff;
    
    /** Configuration properties */
    
    /**
    * The default colour of the lamp
    */
    @com.google.gson.annotations.SerializedName("defaultColour")
    private device.streetlamp.model.datatypes.Colour defaultColour;
    	
    /**
    * Setter for blinking.
    */
    public void setBlinking(boolean blinking) {
    	this.blinking = blinking;
    }
    /**
    * Getter for blinking.
    */
    public boolean getBlinking() {
    	return this.blinking;
    }
    /**
    * Setter for onOff.
    */
    public void setOnOff(int onOff) {
    	this.onOff = onOff;
    }
    /**
    * Getter for onOff.
    */
    public int getOnOff() {
    	return this.onOff;
    }
    /**
    * Setter for defaultColour.
    */
    public void setDefaultColour(device.streetlamp.model.datatypes.Colour defaultColour) {
    	this.defaultColour = defaultColour;
    }
    /**
    * Getter for defaultColour.
    */
    public device.streetlamp.model.datatypes.Colour getDefaultColour() {
    	return this.defaultColour;
    }
    
    public Map getStatusProperties() {
        Map<String, Object> status = new HashMap<String, Object>();
        status.put("blinking", this.blinking);
        status.put("onOff", this.onOff);
    	return status;
    }
    public Map getConfigurationProperties() {
        Map<String, Object> configuration = new HashMap<String, Object>();
        configuration.put("defaultColour", this.defaultColour);
        return configuration;
    }
}
