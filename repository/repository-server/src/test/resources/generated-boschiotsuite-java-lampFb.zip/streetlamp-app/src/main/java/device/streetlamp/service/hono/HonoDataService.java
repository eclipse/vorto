package device.streetlamp.service.hono;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import device.streetlamp.model.Lamp;
import device.streetlamp.model.Address;
import device.streetlamp.service.IDataService;
import com.google.gson.Gson;

/**
 * Data Service Implementation that sends device data to Eclipse Hono MQTT Endpoint
 *
 */
public class HonoDataService implements IDataService {
	
	private String mqttHostUrl;
	private String honoTenant;
	private String dittoNamespace;
	private String authId;
	private String deviceId;
	private String password;
	private Map<String, HonoMqttClient> deviceClients = new HashMap<String, HonoMqttClient>();
	private Gson gson = new Gson();
	
	public HonoDataService(String mqttHostUrl, String honoTenant, String dittoNamespace, String deviceId, String authId, String password) {
		this.mqttHostUrl = Objects.requireNonNull(mqttHostUrl);
		this.honoTenant = Objects.requireNonNull(honoTenant);
		this.dittoNamespace = Objects.requireNonNull(dittoNamespace);
		this.deviceId = Objects.requireNonNull(deviceId);
		this.authId = Objects.requireNonNull(authId);
		this.password = Objects.requireNonNull(password);
	}
	
	public void publishLamp(String resourceId, Lamp lamp) {
		getConnectedHonoClient(resourceId).send("telemetry/" + honoTenant + "/" + resourceId, gson.toJson(wrap(lamp.getStatusProperties(),lamp.getConfigurationProperties(),"lamp")));
	}
	public void publishSpareLamp(String resourceId, Lamp spareLamp) {
		getConnectedHonoClient(resourceId).send("telemetry/" + honoTenant + "/" + resourceId, gson.toJson(wrap(spareLamp.getStatusProperties(),spareLamp.getConfigurationProperties(),"spareLamp")));
	}
	public void publishLocation(String resourceId, Address location) {
		getConnectedHonoClient(resourceId).send("telemetry/" + honoTenant + "/" + resourceId, gson.toJson(wrap(location.getStatusProperties(),location.getConfigurationProperties(),"location")));
	}
	
	private <T> Map<String, Object> wrap(T StatusProperties, T ConfigurationProperties, String featureName) {				
		Map<String, Object> headers = new HashMap<String, Object>();
		headers.put("response-required", Boolean.FALSE);
		
		Map<String, Object> wrapper = new HashMap<String, Object>();
		wrapper.put("topic", dittoNamespace + "/" + deviceId + "/things/twin/commands/modify");
	    wrapper.put("path", "/features/"+featureName);
	    wrapper.put("value", createValue(StatusProperties,ConfigurationProperties));
		wrapper.put("headers", headers);

		return wrapper; 
	}
	
	private <T> Map<String, Object> createValue(T StatusProperties, T ConfigurationProperties) {
		Map<String, Object> value = new HashMap<String, Object>();
		Map<String, Object> properties = new HashMap<String, Object>();
		
		properties.put("status",StatusProperties);
		properties.put("configuration",ConfigurationProperties);
		value.put("properties", properties);
		return value;
	}

	private HonoMqttClient getConnectedHonoClient(String resourceId) {
		HonoMqttClient client = deviceClients.get(resourceId);
		if (client == null) {
			client = new HonoMqttClient(mqttHostUrl, resourceId, authId, password);
			deviceClients.put(resourceId, client);
		}
		
		if (!client.isConnected()) {
			client.connect();
		}
		
		return client;
	}
}
