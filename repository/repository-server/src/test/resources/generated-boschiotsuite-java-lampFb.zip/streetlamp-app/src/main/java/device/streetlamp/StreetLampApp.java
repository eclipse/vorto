package device.streetlamp;

import org.apache.log4j.Logger;

import device.streetlamp.model.Lamp;
import device.streetlamp.service.hono.HonoDataService;

/**
 * Example App that uses the Hono Data Service by sending random data to Eclipse Hono MQTT Connector
 */
public class StreetLampApp {

	private static final Logger LOGGER = Logger.getLogger(StreetLampApp.class);

	/**************************************************************************/
	/* Configuration Section */
	/* Adjust according to your Endpoint Configuration*/
	/**************************************************************************/

	// Hono MQTT Endpoint
	private static final String MQTT_ENDPOINT = "<INSERT HONO MQTT ENDPOINT HERE>";

	// Your Tenant
	private static final String HONO_TENANT = "DEFAULT_TENANT";

	// Your DeviceId
	private static final String DEVICE_ID = "<INSERT DEVICE ID HERE>";
	
	// Device authentication ID
	private static final String AUTH_ID = "<INSERT DEVICE AUTH ID HERE>";
	
	// Ditto Namespace
	private static final String DITTO_NAMESPACE = "com.mycompany";

	// Device authentication Password
	private static final String PASSWORD = "ENTER_DEVICE_PASSWORD";
	
	private static final long SEND_INTERVAL_IN_SECONDS = 2;

	public static void main(final String... args) {
		HonoDataService honoDataService = new HonoDataService(MQTT_ENDPOINT, HONO_TENANT, DITTO_NAMESPACE, 
				DEVICE_ID, AUTH_ID,PASSWORD);
		
		while (true) {
			honoDataService.publishLamp(DEVICE_ID,readLamp());
			try {
				Thread.sleep(SEND_INTERVAL_IN_SECONDS * 1000);
			} catch (InterruptedException e) {
				LOGGER.error(e);
			}
		}
	}

	/**
	* Reads the lamp from the device
	*/
	private static Lamp readLamp() {
		Lamp lamp = new Lamp();
		//Status properties
		lamp.setBlinking(new java.util.Random().nextBoolean());
		//Configuration properties
		return lamp;
	}

}
