package device.streetlamp;

import org.apache.log4j.Logger;

import device.streetlamp.model.Lamp;
import device.streetlamp.model.Address;
import device.streetlamp.service.hono.HonoDataService;

/**
 * Example App that uses the Hono Data Service by sending random data to Eclipse Hono MQTT Connector
 */
public class StreetLampApp {

	private static final Logger LOGGER = Logger.getLogger(StreetLampApp.class);

	/**************************************************************************/
	/* Configuration Section */
	/* Adjust according to your Endpoint Configuration*/
	/**************************************************************************/

	// Hono MQTT Endpoint
	private static final String MQTT_ENDPOINT = "<INSERT HONO MQTT ENDPOINT HERE>";

	// Your Tenant
	private static final String HONO_TENANT = "DEFAULT_TENANT";

	// Your DeviceId
	private static final String DEVICE_ID = "<INSERT DEVICE ID HERE>";
	
	// Device authentication ID
	private static final String AUTH_ID = "<INSERT DEVICE AUTH ID HERE>";
	
	// Ditto topic , e.g. com.mycompany/4711
	private static final String DITTO_TOPIC = "com.mycompany/1234";

	// Device authentication Password
	private static final String PASSWORD = "ENTER_DEVICE_PASSWORD";
	
	private static final long SEND_INTERVAL_IN_SECONDS = 2;

	public static void main(final String... args) {
		HonoDataService honoDataService = new HonoDataService(MQTT_ENDPOINT, HONO_TENANT, DITTO_TOPIC, 
				DEVICE_ID, AUTH_ID,PASSWORD);
		
		while (true) {
			honoDataService.publishLamp(DEVICE_ID,readLamp());
			honoDataService.publishSpareLamp(DEVICE_ID,readSpareLamp());
			honoDataService.publishLocation(DEVICE_ID,readLocation());
			try {
				Thread.sleep(SEND_INTERVAL_IN_SECONDS * 1000);
			} catch (InterruptedException e) {
				LOGGER.error(e);
			}
		}
	}

	/**
	* Reads the lamp from the device
	*/
	private static Lamp readLamp() {
		Lamp lamp = new Lamp();
		//Status properties
		lamp.setBlinking(new java.util.Random().nextBoolean());
		lamp.setOnOff(new java.util.Random().nextInt(100));
		lamp.setDimmer(Math.round(new java.util.Random().nextFloat()*(float)100));
		lamp.setLamp_type("");
		lamp.setBiggerThanInt();
		//Configuration properties
		lamp.setDefaultColour("");
		return lamp;
	}
	/**
	* Reads the spareLamp from the device
	*/
	private static Lamp readSpareLamp() {
		Lamp spareLamp = new Lamp();
		//Status properties
		spareLamp.setBlinking(new java.util.Random().nextBoolean());
		spareLamp.setOnOff(new java.util.Random().nextInt(100));
		spareLamp.setDimmer(Math.round(new java.util.Random().nextFloat()*(float)100));
		spareLamp.setLamp_type("");
		spareLamp.setBiggerThanInt();
		//Configuration properties
		spareLamp.setDefaultColour("");
		return spareLamp;
	}
	/**
	* Reads the location from the device
	*/
	private static Address readLocation() {
		Address location = new Address();
		//Status properties
		location.setDeviceName("");
		//Configuration properties
		location.setText("");
		location.setZone("");
		location.setId(new java.util.Random().nextInt(100));
		location.setIdentifier("");
		return location;
	}

}
