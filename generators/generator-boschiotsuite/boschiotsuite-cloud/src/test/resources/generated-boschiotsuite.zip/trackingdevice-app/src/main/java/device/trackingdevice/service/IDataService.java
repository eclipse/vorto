package device.trackingdevice.service;

import device.trackingdevice.model.Location;

public interface IDataService {
	
	/**
	 * publishes location data to the IoT Cloud backend
	 * @param resourceId 
	 * @param data
	 */
	void publishLocation(String resourceId, Location data);
	
}

